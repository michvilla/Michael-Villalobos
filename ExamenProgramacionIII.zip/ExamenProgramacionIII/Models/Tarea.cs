﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ExamenProgramacionIII.Models
{
    public class Tarea
    {
        [Key]
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public required DateTime FechaCreacion { get; set; }
        public required DateTime FechaLimite {  get; set; }
        public string Estado { get; set; }
        public string Dificultad { get; set; }
        public string TiempoEstimado { get; set; }

        public virtual MetaPrincipal Principal { get; set; }

        [ForeignKey("Id")]
        public int MetaPrincipalId { get; set; }
    }
}
